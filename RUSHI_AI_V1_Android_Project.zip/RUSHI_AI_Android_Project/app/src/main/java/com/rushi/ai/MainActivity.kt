package com.rushi.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Background = Color(0xFF07111F)
private val Panel = Color(0xFF101F33)
private val Blue = Color(0xFF42B8FF)
private val TextMain = Color(0xFFEAF5FF)
private val Muted = Color(0xFF91A9C2)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { RushiApp(
            onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rushi_reply") },
            onListen = { onResult ->
                val recognizer = speechRecognizer
                if (recognizer == null) {
                    onResult("Speech recognition is unavailable on this device.")
                } else {
                    recognizer.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) { onResult("") }
                        override fun onResults(results: Bundle?) {
                            onResult(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty())
                        }
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to RUSHI")
                    }
                    recognizer.startListening(intent)
                }
            }
        ) }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun RushiApp(onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hello. I am RUSHI, your personal assistant.", false),
            ChatMessage("V1.0 is running in local demo mode. AI cloud connection is not configured yet.", false)
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            listening = true
            onListen { result ->
                if (result.isNotBlank()) input = result
                listening = false
            }
        } else listening = false
    }

    fun sendMessage(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        messages.add(ChatMessage(text, true))
        input = ""
        val reply = when {
            text.contains("hello", true) || text.contains("hi", true) ->
                "Hello. RUSHI is online. What can I help you with?"
            text.contains("your name", true) ->
                "I am RUSHI, your personal AI assistant."
            text.contains("time", true) ->
                "I can add live time and date tools in the next build."
            else ->
                "I received your message: \"$text\". My chat, voice input and speech output are ready. Connect an AI service in the next development stage to enable intelligent answers."
        }
        messages.add(ChatMessage(reply, false))
        onSpeak(reply)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Background, surface = Panel,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Column(
            Modifier.fillMaxSize().background(Background).statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 18.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(44.dp).background(Color(0xFF123B5B), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("R", color = Blue, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("RUSHI AI", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("PERSONAL ASSISTANT  •  V1.0", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                }
                Surface(color = Color(0xFF123B35), shape = RoundedCornerShape(20.dp)) {
                    Text("● ONLINE", color = Color(0xFF68E0B2), modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), fontSize = 10.sp)
                }
            }

            Box(
                Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    .background(Panel, RoundedCornerShape(20.dp)).padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(112.dp).background(Color(0xFF0D2A43), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◉", color = Blue, fontSize = 58.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(if (listening) "LISTENING..." else "READY WHEN YOU ARE", color = Blue, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text("Your voice. Your assistant.", color = Muted, fontSize = 12.sp)
                }
            }

            Text("CONVERSATION", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 8.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                reverseLayout = false,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (message.fromUser) Color(0xFF123B5B) else Panel,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) {
                            Text(message.text, color = TextMain, modifier = Modifier.padding(13.dp), fontSize = 14.sp, lineHeight = 20.sp)
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp)
                    .background(Panel, RoundedCornerShape(28.dp)).padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(vertical = 9.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 14.sp),
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) Text("Message RUSHI...", color = Muted, fontSize = 14.sp)
                            inner()
                        }
                    }
                )
                IconButton(onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        listening = true
                        onListen { result -> if (result.isNotBlank()) input = result; listening = false }
                    } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }) {
                    Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Blue)
                }
                IconButton(onClick = { sendMessage(input) }) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Blue)
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Muted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(5.dp))
                Text("VOICE RESPONSES ENABLED", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
    }
}
